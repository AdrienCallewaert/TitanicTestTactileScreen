// build-manifest.js
const fs = require("fs");
const path = require("path");

const roots = [
  "Assets/images/Deck",
  "Assets/images/Engine",
  "Assets/images/Gallery",
  "Assets/images/Passengers",
];

const exts = new Set([".png", ".jpg", ".jpeg", ".webp", ".svg", ".gif", ".avif"]);

function walk(dir) {
  let files = [];
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) files = files.concat(walk(full));
    else if (exts.has(path.extname(entry.name).toLowerCase())) {
      files.push(full.replace(/\\/g, "/"));
    }
  }
  return files;
}

const all = roots.flatMap(walk).sort();
fs.writeFileSync("sw-manifest.json", JSON.stringify(all, null, 2), "utf8");
console.log(`Manifest créé avec ${all.length} fichiers.`);
